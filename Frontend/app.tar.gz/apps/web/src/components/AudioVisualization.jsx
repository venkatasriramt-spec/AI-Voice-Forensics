import React from 'react';
import { motion } from 'framer-motion';

const AudioVisualization = () => {
  return (
    <div className="w-full h-full flex flex-col rounded-xl overflow-hidden bg-[hsl(var(--background-lighter))] border border-border">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-background/50">
        <h3 className="font-mono text-sm tracking-wide text-primary uppercase">Mel-Spectrogram Analysis</h3>
        <span className="font-mono text-xs text-muted-foreground">16.0 kHz STFT</span>
      </div>
      
      <div className="relative flex-1 p-4 min-h-[300px] flex">
        {/* Y-Axis */}
        <div className="flex flex-col justify-between pr-4 font-mono text-[10px] text-muted-foreground border-r border-border/50 text-right w-12">
          <span>8kHz</span>
          <span>6kHz</span>
          <span>4kHz</span>
          <span>2kHz</span>
          <span>0Hz</span>
        </div>

        {/* Main Vis Area */}
        <div className="relative flex-1 ml-4 bg-background/50 rounded overflow-hidden">
          {/* Reference image for spectrogram */}
          <div 
            className="absolute inset-0 opacity-80 mix-blend-screen bg-cover bg-center"
            style={{ 
              backgroundImage: 'url(https://images.unsplash.com/photo-1548230445-ca4ebd9755a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80)',
              filter: 'hue-rotate(180deg) saturate(2) brightness(0.8)' // Shifts to cyan/blue tones
            }}
          />
          
          {/* Scanning Line Animation */}
          <motion.div
            className="absolute top-0 bottom-0 w-1 bg-primary shadow-[0_0_15px_rgba(0,217,255,0.8)] z-10"
            initial={{ left: '0%' }}
            animate={{ left: ['0%', '100%'] }}
            transition={{ duration: 4, ease: "linear", repeat: Infinity }}
          />
          
          {/* Grid Overlay */}
          <div className="absolute inset-0 pointer-events-none" style={{
            backgroundImage: `linear-gradient(to right, rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.05) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }} />
        </div>
      </div>

      {/* X-Axis */}
      <div className="pl-20 pr-4 pb-4 flex justify-between font-mono text-[10px] text-muted-foreground">
        <span>0.0s</span>
        <span>2.5s</span>
        <span>5.0s</span>
        <span>7.5s</span>
        <span>10.0s</span>
      </div>
    </div>
  );
};

export default AudioVisualization;