
import React from 'react';
import { motion } from 'framer-motion';
import { ShieldAlert, ShieldCheck, Activity, Cpu, AlertTriangle } from 'lucide-react';

const ThreatMatrix = ({ confidence, latency = '1.04', mode = 'static' }) => {
  // Determine tier based on pure fake probability and mode thresholds
  let activeTier = 0;
  
  if (mode === 'static') {
    if (confidence < 1.5) activeTier = 0;
    else if (confidence < 15) activeTier = 1;
    else if (confidence < 85) activeTier = 2;
    else if (confidence < 98.5) activeTier = 3;
    else activeTier = 4;
  } else {
    if (confidence < 5) activeTier = 0;
    else if (confidence < 20) activeTier = 1;
    else if (confidence < 50) activeTier = 2;
    else if (confidence < 85) activeTier = 3;
    else activeTier = 4;
  }

  const tiers = [
    { name: 'VERIFIED', range: mode === 'static' ? '<1.5%' : '<5%', color: 'text-success border-success/50 bg-success/10', glow: 'shadow-[0_0_15px_rgba(16,185,129,0.3)]', desc: 'Authentic Human', bgSolid: 'bg-success' },
    { name: 'LOW RISK', range: mode === 'static' ? '1.5-15%' : '5-20%', color: 'text-[#34d399] border-[#34d399]/50 bg-[#34d399]/10', glow: 'shadow-[0_0_15px_rgba(52,211,153,0.3)]', desc: 'Minor Anomalies', bgSolid: 'bg-[#34d399]' },
    { name: 'ELEVATED RISK', range: mode === 'static' ? '15-85%' : '20-50%', color: 'text-warning border-warning/50 bg-warning/10', glow: 'shadow-[0_0_15px_rgba(245,158,11,0.3)]', desc: 'Suspicious Audio', bgSolid: 'bg-warning' },
    { name: 'HIGH RISK', range: mode === 'static' ? '85-98.5%' : '50-85%', color: 'text-[#ff6b6b] border-[#ff6b6b]/50 bg-[#ff6b6b]/10', glow: 'shadow-[0_0_15px_rgba(255,107,107,0.3)]', desc: 'Probable AI Generation', bgSolid: 'bg-[#ff6b6b]' },
    { name: 'CRITICAL', range: mode === 'static' ? '≥98.5%' : '≥85%', color: 'text-critical border-critical/50 bg-critical/10', glow: 'shadow-[0_0_15px_rgba(220,38,38,0.3)]', desc: 'Confirmed Synthetic Deepfake', bgSolid: 'bg-critical' },
  ];

  const current = tiers[activeTier];

  return (
    <div className="w-full flex flex-col gap-6">
      {/* Top Score Box */}
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className={`p-6 rounded-xl border-2 ${current.color} ${current.glow} flex flex-col items-center justify-center text-center relative overflow-hidden`}
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-current to-transparent opacity-50" />
        <h3 className="font-mono text-xs uppercase tracking-widest mb-2 opacity-80">Synthetic AI Probability</h3>
        <div className="text-6xl md:text-7xl font-mono font-bold tracking-tighter drop-shadow-md">
          {confidence.toFixed(1)}%
        </div>
        <p className="mt-3 font-medium tracking-wide flex items-center gap-2">
          {activeTier >= 3 ? <AlertTriangle className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
          {current.desc}
        </p>
      </motion.div>

      {/* 5-Tier Matrix */}
      <div className="bg-[hsl(var(--background-lighter))] border border-border rounded-xl p-5">
        <h4 className="font-mono text-xs uppercase text-muted-foreground mb-4 tracking-wider">Threat Assessment Matrix</h4>
        <div className="space-y-2">
          {tiers.map((tier, idx) => {
            const isActive = idx === activeTier;
            return (
              <div 
                key={idx} 
                className={`flex items-center justify-between p-2.5 rounded-lg border transition-all ${
                  isActive 
                    ? `${tier.color} scale-[1.02] ${tier.glow} z-10 relative` 
                    : 'border-border/30 bg-background/30 text-muted-foreground'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${isActive ? tier.bgSolid : 'bg-border'}`} />
                  <span className="font-semibold text-sm">{tier.name}</span>
                </div>
                <span className="font-mono text-xs opacity-70">{tier.range}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Telemetry Data */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[hsl(var(--background-lighter))] border border-border p-4 rounded-xl">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Cpu className="w-4 h-4" />
            <h5 className="font-mono text-[10px] uppercase tracking-wider">Processing Latency</h5>
          </div>
          <p className="font-mono text-lg text-foreground">{latency} ms</p>
        </div>
        <div className="bg-[hsl(var(--background-lighter))] border border-border p-4 rounded-xl">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Activity className="w-4 h-4" />
            <h5 className="font-mono text-[10px] uppercase tracking-wider">Primary Flag</h5>
          </div>
          <p className="text-sm font-medium text-foreground leading-tight">
            {activeTier >= 3 ? 'Synthetic artifacts detected' : 'Organic acoustic flow'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ThreatMatrix;
